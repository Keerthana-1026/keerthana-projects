// src/app/models/user.model.ts
export interface User {
  fullName: string;
  email: string;
  address: string;
  gamerName: string;
  country: string;
  password: string;
}
