import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { QuizService } from '../../services/quiz.service';

@Component({
  selector: 'app-instruction',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './instruction.component.html',
  styleUrls: ['./instruction.component.scss']
})
export class InstructionComponent {
  quiz: any;
  constructor(private route: ActivatedRoute, private quizService: QuizService, private router: Router) {
    const id = Number(this.route.snapshot.paramMap.get('quizId'));
    this.quiz = this.quizService.getQuizById(id);
  }

  startQuiz() {
    this.router.navigate(['/quiz', this.quiz.id]);
  }
}
