import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QuizService } from '../../services/quiz.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-quiz',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.scss']
})
export class QuizComponent implements OnInit {
  questions: any[] = [];
  currentIndex = 0;
  selectedAnswer = '';
  score = 0;

  questionStatus: ('unanswered' | 'answered' | 'review')[] = [];
  userAnswers: { question: string; selected: string; correct: string }[] = [];

  perTimer = 15;
  globalTimer!: number;
  perTimerRef: any;
  globalTimerRef: any;
  progressPercent = 0;
  optionsShuffled: string[] = [];

  constructor(private route: ActivatedRoute, private quizService: QuizService, private router: Router) {}

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('quizId'));
    this.questions = this.shuffleArray(this.quizService.getQuestions(id));
    this.globalTimer = this.questions.length * 15;
    this.questionStatus = new Array(this.questions.length).fill('unanswered');

    this.startTimers();
    this.updateQuestion();
  }

  shuffleArray(arr: any[]) { return arr.sort(() => Math.random() - 0.5); }

  startTimers() {
    this.resetPerTimer();
    this.globalTimerRef = setInterval(() => {
      this.globalTimer--;
      if (this.globalTimer <= 0) this.submitQuiz();
    }, 1000);
  }

  resetPerTimer() {
    clearInterval(this.perTimerRef);
    this.perTimer = 15;
    this.perTimerRef = setInterval(() => {
      this.perTimer--;
      if (this.perTimer <= 0) this.autoSkip();
    }, 1000);
  }

  updateQuestion() {
  const answer = this.userAnswers[this.currentIndex]?.selected;
  this.selectedAnswer = answer === 'Skipped' ? '' : answer || '';
  this.optionsShuffled = this.shuffleArray(this.questions[this.currentIndex].options);
  this.updateProgress();
  this.resetPerTimer();
}


  autoSkip() {
    this.saveSelection('Skipped', false);
    this.moveNext();
  }

  saveSelection(opt: string, move = false, markAs?: 'answered' | 'review') {
    const current = this.questions[this.currentIndex];
    this.userAnswers[this.currentIndex] = {
      question: current.q, selected: opt, correct: current.answer
    };

    if (opt === current.answer) this.score++;
    this.questionStatus[this.currentIndex] = markAs || 'answered';

    if (move) this.moveNext();
  }

  saveAnswer() { if (!this.selectedAnswer) return; this.saveSelection(this.selectedAnswer, true); }

  markForReview() { this.saveSelection(this.selectedAnswer || '', true, 'review'); }

  skip() { this.saveSelection('Skipped', true); }

  moveNext() {
  clearInterval(this.perTimerRef);
  if (this.currentIndex < this.questions.length - 1) {
    this.currentIndex++;
    this.updateQuestion();
  } else {
    // Do NOT auto-submit — just stop at last question
    this.currentIndex = this.questions.length - 1;
    this.updateQuestion();
  }
}


  jumpToQuestion(i: number) { clearInterval(this.perTimerRef); this.currentIndex = i; this.updateQuestion(); }

  submitQuiz() {
    clearInterval(this.perTimerRef);
    clearInterval(this.globalTimerRef);
    localStorage.setItem('score', String(this.score));
    localStorage.setItem('totalQuestions', String(this.questions.length));
    localStorage.setItem('review', JSON.stringify(this.userAnswers));
    localStorage.setItem('questionStatus', JSON.stringify(this.questionStatus));
    localStorage.setItem('lastQuizId', this.route.snapshot.paramMap.get('quizId')!);
    this.router.navigate(['/result']);
  }

  exitQuiz() {
    if (confirm('Exit and submit quiz now?')) this.submitQuiz();
  }

  updateProgress() {
    this.progressPercent = ((this.currentIndex + 1) / this.questions.length) * 100;
  }
}
