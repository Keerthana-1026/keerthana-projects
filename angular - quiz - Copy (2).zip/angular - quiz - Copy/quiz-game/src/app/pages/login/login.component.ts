import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { User } from '../../models/user.model';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  gamerName = '';
  password = '';

  constructor(private router: Router, private userService: UserService) {}

  login() {
    const storedUser = localStorage.getItem('user');

    if (!storedUser) {
      alert('No user found. Please sign up.');
      return;
    }

    const user: User = JSON.parse(storedUser);

    if (user.gamerName === this.gamerName && user.password === this.password) {
      alert('Login successful!');
      localStorage.setItem('user', JSON.stringify(user)); // Optional: refresh
      this.userService.setUsername(this.gamerName);
      this.router.navigate(['/']);
    } else {
      alert('Invalid gamer name or password.');
    }
  }
}
