import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent {
  fullName = '';
  email = '';
  address = '';
  gamerName = '';
  country = '';
  password = '';

  constructor(private router: Router) {}

  signup() {
    if (this.fullName && this.email && this.gamerName && this.password) {
      const user: User = {
        fullName: this.fullName,
        email: this.email,
        address: this.address,
        gamerName: this.gamerName,
        country: this.country,
        password: this.password
      };

      localStorage.setItem('user', JSON.stringify(user));
      alert('Signup successful!');
      this.router.navigate(['/login']); // Redirect to login
    } else {
      alert('Please fill all required fields.');
    }
  }
}
