import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router'; // ✅ Import Router

@Component({
  selector: 'app-edit-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {
  fullName = '';
  email = '';
  address = '';
  gamerName = '';
  country = '';
  password = '';
  interestedTopics: string[] = [];
  educationLevel = '';
  profileImageBase64 = '';
  topicsList = ['Angular', 'JavaScript', 'HTML/CSS', 'Databases', 'Cybersecurity'];

  constructor(private router: Router) {} // ✅ Inject Router

  ngOnInit() {
    const user = JSON.parse(localStorage.getItem('user')!);
    if (user) {
      this.fullName = user.fullName || '';
      this.email = user.email || '';
      this.address = user.address || '';
      this.gamerName = user.gamerName || '';
      this.country = user.country || '';
      this.password = user.password || '';
      this.interestedTopics = user.interestedTopics || [];
      this.educationLevel = user.educationLevel || '';
      this.profileImageBase64 = user.profileImageBase64 || '';
    }
  }

  toggleTopic(topic: string) {
    if (this.interestedTopics.includes(topic)) {
      this.interestedTopics = this.interestedTopics.filter(t => t !== topic);
    } else {
      this.interestedTopics.push(topic);
    }
  }

  onImageUpload(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.profileImageBase64 = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  update() {
    const updatedUser = {
      fullName: this.fullName,
      email: this.email,
      address: this.address,
      gamerName: this.gamerName,
      country: this.country,
      password: this.password,
      interestedTopics: this.interestedTopics,
      educationLevel: this.educationLevel,
      profileImageBase64: this.profileImageBase64
    };
    localStorage.setItem('user', JSON.stringify(updatedUser));
    alert('Profile updated successfully!');
    this.router.navigate(['/']); // ✅ Navigate to home page
  }
}
