import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-result',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent {
  score: number = 0;
  total: number = 0;
  lastQuizId: number | null = null;
  questionStatus: string[] = [];

  reviewData: { question: string; selected: string; correct: string }[] = [];
  correctAnswers: { question: string; selected: string; correct: string }[] = [];
  wrongAnswers: { question: string; selected: string; correct: string }[] = [];

  constructor(private router: Router) {
    const savedScore = localStorage.getItem('score');
    this.score = savedScore ? Number(savedScore) : 0;

    const savedTotal = localStorage.getItem('totalQuestions');
    this.total = savedTotal ? Number(savedTotal) : 0;

    const review = localStorage.getItem('review');
    this.reviewData = review ? JSON.parse(review) : [];

    const lastQuizId = localStorage.getItem('lastQuizId');
    this.lastQuizId = lastQuizId ? Number(lastQuizId) : null;

    const qStatus = localStorage.getItem('questionStatus');
    this.questionStatus = qStatus ? JSON.parse(qStatus) : [];

    this.correctAnswers = this.reviewData.filter(item => item.selected === item.correct);
    this.wrongAnswers = this.reviewData.filter(item => item.selected !== item.correct);
  } // 👈 ✅ Constructor ends here

  goHome() {
    this.router.navigate(['/']);
  }

  playAgain() {
    if (this.lastQuizId !== null) {
      this.router.navigate(['/quiz', this.lastQuizId]);
    }
  }
}
