import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UserService {
  private usernameSubject = new BehaviorSubject<string | null>(this.getStoredUsername());
  username$ = this.usernameSubject.asObservable();

  private getStoredUsername(): string | null {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user).gamerName : null;
  }

  setUsername(name: string) {
    this.usernameSubject.next(name);
  }

  clearUsername() {
    this.usernameSubject.next(null);
  }
}
