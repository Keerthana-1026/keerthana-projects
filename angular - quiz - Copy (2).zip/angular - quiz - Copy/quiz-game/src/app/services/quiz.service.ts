import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class QuizService {
  private quizzes = [
    { id: 1, title: 'HTML Basics', description: 'Test your HTML knowledge' },
    { id: 2, title: 'Angular Advanced', description: 'Challenge your Angular skills' },
    { id: 3, title: 'General Knowledge', description: 'How well do you know the world?' },
    { id: 4, title: 'Indian History', description: 'Explore the timeline of India’s past' },
    { id: 5, title: 'Politics & Constitution', description: 'Test your knowledge of governance' }
  ];

  private questions: { [key: number]: { q: string; options: string[]; answer: string }[] } = {
    1: [
      { q: 'What does HTML stand for?', options: ['Hyperlinks and Text Markup Language', 'Hyper Text Markup Language', 'Home Tool Markup Language'], answer: 'Hyper Text Markup Language' },
      { q: 'Who is the inventor of HTML?', options: ['Tim Berners-Lee', 'Brendan Eich', 'Bjarne Stroustrup'], answer: 'Tim Berners-Lee' },
      { q: 'What is the correct HTML element for inserting a line break?', options: ['<break>', '<br>', '<lb>'], answer: '<br>' },
      { q: 'Which tag is used to make text bold?', options: ['<strong>', '<b>', 'Both'], answer: 'Both' },
      { q: 'What is the purpose of the <head> tag?', options: ['Contains metadata', 'Contains body content', 'Displays the title'], answer: 'Contains metadata' },
      { q: 'Which attribute is used to provide an image path?', options: ['src', 'href', 'alt'], answer: 'src' },
      { q: 'Which HTML tag is used for lists?', options: ['<ol>', '<ul>', 'Both'], answer: 'Both' },
      { q: 'Which tag is used to create a hyperlink?', options: ['<a>', '<link>', '<href>'], answer: '<a>' },
      { q: 'Which tag is used for inserting a background color?', options: ['<body style="background-color:...">', '<bg>', '<background>'], answer: '<body style="background-color:...">' },
      { q: 'What is the default alignment of text in HTML?', options: ['Center', 'Justify', 'Left'], answer: 'Left' }
    ],
    2: [
      { q: 'Angular is based on which programming language?', options: ['Python', 'JavaScript', 'TypeScript'], answer: 'TypeScript' },
      { q: 'What is the purpose of Angular CLI?', options: ['Design UI', 'Scaffold Angular applications', 'Write backend'], answer: 'Scaffold Angular applications' },
      { q: 'What does a component consist of?', options: ['HTML + CSS only', 'Class + Template + Metadata', 'Service only'], answer: 'Class + Template + Metadata' },
      { q: 'Which directive is used for conditional rendering?', options: ['*ngIf', '*ngFor', 'ngSwitch'], answer: '*ngIf' },
      { q: 'Which file defines the root module?', options: ['app.component.ts', 'app.module.ts', 'main.ts'], answer: 'app.module.ts' },
      { q: 'Which decorator defines an Angular component?', options: ['@Injectable', '@NgModule', '@Component'], answer: '@Component' },
      { q: 'What is data binding in Angular?', options: ['Binding data between components', 'Binding data between model and view', 'Connecting APIs'], answer: 'Binding data between model and view' },
      { q: 'Which command creates a new component?', options: ['ng new', 'ng generate component', 'ng build'], answer: 'ng generate component' },
      { q: 'What is the purpose of services in Angular?', options: ['Storing static data', 'Providing business logic and shared data', 'Creating UI only'], answer: 'Providing business logic and shared data' },
      { q: 'What is a pipe used for in Angular?', options: ['Modifying templates', 'Transforming data in the template', 'Creating HTTP calls'], answer: 'Transforming data in the template' }
    ],
    3: [
      { q: 'What is the capital of Australia?', options: ['Sydney', 'Melbourne', 'Canberra'], answer: 'Canberra' },
      { q: 'Which planet is known as the Red Planet?', options: ['Earth', 'Venus', 'Mars'], answer: 'Mars' },
      { q: 'Which is the longest river in the world?', options: ['Amazon', 'Nile', 'Yangtze'], answer: 'Nile' },
      { q: 'What is the smallest prime number?', options: ['1', '2', '3'], answer: '2' },
      { q: 'Which language has the most native speakers?', options: ['English', 'Mandarin', 'Hindi'], answer: 'Mandarin' },
      { q: 'What gas do plants absorb?', options: ['Oxygen', 'Carbon Dioxide', 'Nitrogen'], answer: 'Carbon Dioxide' },
      { q: 'What is the hardest natural substance?', options: ['Gold', 'Iron', 'Diamond'], answer: 'Diamond' },
      { q: 'How many continents are there?', options: ['5', '6', '7'], answer: '7' },
      { q: 'Which ocean is the deepest?', options: ['Atlantic', 'Arctic', 'Pacific'], answer: 'Pacific' },
      { q: 'Which animal is known as the "Ship of the Desert"?', options: ['Camel', 'Horse', 'Donkey'], answer: 'Camel' }
    ],
    4: [
      { q: 'Who was the first President of India?', options: ['Jawaharlal Nehru', 'B.R. Ambedkar', 'Dr. Rajendra Prasad'], answer: 'Dr. Rajendra Prasad' },
      { q: 'In which year did India gain independence?', options: ['1945', '1947', '1950'], answer: '1947' },
      { q: 'Who founded the Maurya Empire?', options: ['Ashoka', 'Chandragupta Maurya', 'Bindusara'], answer: 'Chandragupta Maurya' },
      { q: 'What was the capital of the Gupta Empire?', options: ['Pataliputra', 'Delhi', 'Kanchipuram'], answer: 'Pataliputra' },
      { q: 'Who wrote Arthashastra?', options: ['Valmiki', 'Kautilya', 'Kalidasa'], answer: 'Kautilya' },
      { q: 'Who led the Salt March in 1930?', options: ['Subhash Chandra Bose', 'Gandhi', 'Nehru'], answer: 'Gandhi' },
      { q: 'The Battle of Plassey was fought in?', options: ['1757', '1857', '1764'], answer: '1757' },
      { q: 'Who was the founder of the Mughal Empire?', options: ['Akbar', 'Babur', 'Humayun'], answer: 'Babur' },
      { q: 'What was the name of Gandhi’s first ashram in India?', options: ['Sabarmati', 'Sevagram', 'Phoenix'], answer: 'Sabarmati' },
      { q: 'The Quit India Movement started in?', options: ['1940', '1942', '1944'], answer: '1942' }
    ],
    5: [
      { q: 'What is the full form of BJP?', options: ['Bharat Jan Party', 'Bharatiya Janata Party', 'Bharat Justice Party'], answer: 'Bharatiya Janata Party' },
      { q: 'The Indian Constitution came into effect on?', options: ['15 Aug 1947', '26 Jan 1950', '2 Oct 1949'], answer: '26 Jan 1950' },
      { q: 'How many articles were originally there in the Indian Constitution?', options: ['395', '444', '370'], answer: '395' },
      { q: 'Who is known as the Father of the Indian Constitution?', options: ['Gandhi', 'Jawaharlal Nehru', 'B.R. Ambedkar'], answer: 'B.R. Ambedkar' },
      { q: 'Who appoints the Chief Minister of a state?', options: ['President', 'Governor', 'Prime Minister'], answer: 'Governor' },
      { q: 'What is the minimum age to vote in India?', options: ['16', '18', '21'], answer: '18' },
      { q: 'How many members are nominated to Rajya Sabha by the President?', options: ['10', '12', '15'], answer: '12' },
      { q: 'Which house is more powerful in a money bill?', options: ['Lok Sabha', 'Rajya Sabha', 'Both'], answer: 'Lok Sabha' },
      { q: 'How long is the term of a President in India?', options: ['4 years', '5 years', '6 years'], answer: '5 years' },
      { q: 'How many schedules are there in the Indian Constitution?', options: ['10', '12', '14'], answer: '12' }
    ]
  };

  getQuizzes() {
    return this.quizzes;
  }

  getQuizById(id: number) {
    return this.quizzes.find(q => q.id === id);
  }

  getQuestions(quizId: number) {
    return this.questions[quizId];
  }
}
 




