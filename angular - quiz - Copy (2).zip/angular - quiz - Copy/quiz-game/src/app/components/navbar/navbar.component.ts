import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  username: string | null = '';

  constructor(private router: Router, private userService: UserService) {
    this.userService.username$.subscribe(name => {
      this.username = name;
    });
  }

  logout() {
    localStorage.removeItem('user');
    this.userService.clearUsername();
    this.router.navigate(['/login']);
    localStorage.removeItem('score');
    localStorage.removeItem('totalQuestions');
  }
}
