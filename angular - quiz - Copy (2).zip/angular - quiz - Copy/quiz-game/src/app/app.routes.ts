import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { SignupComponent } from './pages/signup/signup.component';
import { InstructionComponent } from './pages/instruction/instruction.component';
import { QuizComponent } from './pages/quiz/quiz.component';
import { ResultComponent } from './pages/result/result.component';
import { EditProfileComponent } from './pages/edit-profile/edit-profile.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'instruction/:quizId', component: InstructionComponent },
  { path: 'quiz/:quizId', component: QuizComponent },
  { path: 'result', component: ResultComponent },
  { path: 'edit-profile', component: EditProfileComponent },
];
