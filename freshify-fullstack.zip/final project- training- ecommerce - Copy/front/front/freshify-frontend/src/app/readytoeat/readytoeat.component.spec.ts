import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadyToEatComponent } from './readytoeat.component';

describe('ReadytoeatComponent', () => {
  let component: ReadyToEatComponent;
  let fixture: ComponentFixture<ReadyToEatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ReadyToEatComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ReadyToEatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
