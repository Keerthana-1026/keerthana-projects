import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import { ProductService } from '../services/product.service';
import { WishlistService } from '../services/wishlist.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  products: any[] = []; // All products
  filteredProducts: any[] = []; // Filtered products based on search
  searchQuery: string = ''; // Holds the search query

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private wishlistService: WishlistService
  ) {}

  ngOnInit(): void {
    this.loadProducts();

    this.productService.getProducts().subscribe((data)=>{
      this.products=data;

    });
  }

  loadProducts(): void {
    this.productService.getProducts().subscribe({
      next: (data) => {
        this.products = data;
        this.filteredProducts = data; // Initially show all products
        console.log('Products loaded:', this.products); // Debugging log
      },
      error: (err) => {
        console.error('Error fetching products:', err);
      },
    });
  }
  

  // Function to filter products based on the search query
  // Function to filter products based on the search query
  filterProducts(): void {
    if (this.searchQuery.trim() === '') {
      this.filteredProducts = this.products; // Show all products when search is empty
    } else {
      this.filteredProducts = this.products.filter((product) =>
        product.name.toLowerCase().includes(this.searchQuery.toLowerCase()) // Match the product name with search query (partial match)
      );
    }
  }

  addToCart(product: any): void {
    this.cartService.addToCart(product);
  }

  

  addToWishlist(product: any): void {
    this.wishlistService.addToWishlist(product).subscribe(
      () => {
        alert('Item added to wishlist');
      },
      (error) => {
        console.error('Error adding to wishlist', error);
      }
    );
  }
}
