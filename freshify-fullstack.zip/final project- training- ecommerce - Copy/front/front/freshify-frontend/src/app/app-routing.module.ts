import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { ProfileComponent } from './profile/profile.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import { FruitsComponent } from './fruits/fruits.component';
import { ReadyToEatComponent } from './readytoeat/readytoeat.component';
import { LogoutComponent } from './logout/logout.component';
import { VegetablesComponent } from './vegetables/vegetables.component';
//import { SnacksComponent } from './snacks/snacks.component';
import { OrderConfirmationComponent } from './order-confirmation/order-confirmation.component';

const routes: Routes = [
  { path: '', component: HomeComponent }, // Default route for the home page
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'wishlist', component: WishlistComponent },
  { path: 'cart', component: CartComponent },
  //{ path: 'cart', component: CartComponent },
  { path: '', redirectTo: '/cart', pathMatch: 'full' },
  { path: 'profile', component: ProfileComponent },
  { path:'payment', component:PaymentComponent},
  { path: 'logout', component: LogoutComponent },
  { path: 'fruits', component: FruitsComponent },
  {path:'readyToEat', component:ReadyToEatComponent},
  {path:'vegetables',component:VegetablesComponent},
  { path: 'order-confirmation', component: OrderConfirmationComponent },
  //{path:'snacks',component:SnacksComponent}
  
 //{ path: '**', redirectTo: '' }, // Wildcard route must be last
];




@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
