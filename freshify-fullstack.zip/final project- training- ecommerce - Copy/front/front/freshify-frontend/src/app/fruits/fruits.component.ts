import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CartService } from '../services/cart.service';  // Import CartService
import { WishlistService } from '../services/wishlist.service';  // Import WishlistService

@Component({
  selector: 'app-fruits',
  templateUrl: './fruits.component.html',
  styleUrls: ['./fruits.component.css']
})
export class FruitsComponent implements OnInit {
  fruits: any[] = [];

  constructor(
    private http: HttpClient,
    private cartService: CartService,  // Inject CartService
    private wishlistService: WishlistService  // Inject WishlistService
  ) {}

  ngOnInit(): void {
    // Fetch products from the JSON file and filter by category 'Fruits'
    this.http.get<any[]>('/assets/products1.json').subscribe((data) => {
      this.fruits = data.filter(product => product.category === 'Fruits');
    });
  }

  // Add product to cart
  addToCart(product: any): void {
    
    this.cartService.addToCart(product);  // Call CartService to add product to cart
    console.log(`${product.name} added to cart.`);
  }

  // Add product to wishlist
  addToWishlist(product: any): void {
    this.wishlistService.addToWishlist(product).subscribe(
      (response) => {
        console.log(`${product.name} added to wishlist.`);
        alert('Product added to wishlist');
      },
      (error) => {
        console.error('Error adding to wishlist', error);
      }
    );
  }
}
