import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service'; // Import AuthService
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  loginData = {
    username: '',
    password: ''
  };
  
  constructor(private authService: AuthService, private router: Router) {}
  
  onSubmit() {
    this.authService.login(this.loginData).subscribe(
      (response) => {
        console.log('Login successful:', response);
        alert('Login successful!');
        this.router.navigate(['/']); // Redirect to homepage
      },
      (error) => {
        console.error('Login error:', error);
        if (error.status === 400) {
          alert('Invalid username or password.');
        } else {
          alert('An unexpected error occurred. Please try again.');
        }
      }
    );
  }
}
