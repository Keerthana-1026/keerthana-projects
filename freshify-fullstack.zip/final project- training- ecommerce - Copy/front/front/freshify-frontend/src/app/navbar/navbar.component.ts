import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service'; // Import AuthService to check login status
 
import { CartService } from '../services/cart.service';
import { WishlistService } from '../services/wishlist.service';
 
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  isLoggedIn: boolean = false; // Flag to check if the user is logged in
  cartCount: number = 0;
  wishlistCount: number = 0;
  user: { name: string; email: string } | null = null;

 
 
  constructor(
    private router: Router,
    private authService: AuthService,
    private wishlistService:WishlistService,
   
    private cartService: CartService
  ) {}
 
  ngOnInit(): void {
    // Check if the user is logged in when the navbar loads
    this.isLoggedIn = this.authService.isLoggedIn();
   
 
    // Subscribe to wishlist data
    // this.wishlistService.wishlist$.subscribe((wishlist) => {
    //   this.wishlistCount = wishlist.length;
    // });
   
 
    // Subscribe to cart count updates from CartService
    this.cartService.cartCount$.subscribe((count) => {
      this.cartCount = count; // Update cart count in navbar
    });
 
    // // Subscribe to user changes
    // this.authService.user$.subscribe((user) => {
    //   this.user = user;
    // });
  }
   
 
  // Navigate to Profile page if logged in
  goToProfile(): void {
    this.router.navigate(['/profile']);
  }
 
  // Navigate to Login page
  goToLogin(): void {
    this.router.navigate(['/login']);
  }
 
  // Navigate to Signup page
  goToSignup(): void {
    this.router.navigate(['/signup']);
  }
 
  logout(): void {
    this.authService.logout(); // Clear user session
    alert('Logout successful!');
    this.router.navigate(['/']); // Redirect to login page
  }
 
  
}
