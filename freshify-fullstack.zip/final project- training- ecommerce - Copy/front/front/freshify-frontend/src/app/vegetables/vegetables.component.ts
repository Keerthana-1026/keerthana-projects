import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CartService } from '../services/cart.service'; // Import CartService
import { WishlistService } from '../services/wishlist.service'; // Import WishlistService

@Component({
  selector: 'app-vegetables',
  templateUrl: './vegetables.component.html',
  styleUrls: ['./vegetables.component.css']
})
export class VegetablesComponent implements OnInit {
  vegetables: any[] = [];

  constructor(
    private http: HttpClient,
    private cartService: CartService, // Inject CartService
    private wishlistService: WishlistService // Inject WishlistService
  ) {}

  ngOnInit(): void {
    // Fetch products from the JSON file and filter by category 'Vegetables'
    this.http.get<any[]>('/assets/products1.json').subscribe((data) => {
      this.vegetables = data.filter(product => product.category === 'Vegetables');
    });
  }

  // Add product to cart
  addToCart(product: any): void {
    this.cartService.addToCart(product); // Call CartService to add product to cart
    console.log(`${product.name} added to cart.`);
  }

  // Add product to wishlist
  addToWishlist(product: any): void {
    this.wishlistService.addToWishlist(product).subscribe(
      (response) => {
        console.log(`${product.name} added to wishlist.`);
        alert('Product added to wishlist');
      },
      (error) => {
        console.error('Error adding to wishlist', error);
      }
    );
  }
}
