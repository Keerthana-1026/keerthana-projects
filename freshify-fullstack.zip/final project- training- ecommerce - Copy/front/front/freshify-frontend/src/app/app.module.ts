import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // Import Forms Modules
import { RouterModule } from '@angular/router';
import { HttpClientModule, provideHttpClient, withFetch } from '@angular/common/http';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AppRoutingModule } from './app-routing.module';
import { ProfileComponent } from './profile/profile.component';
import { RegisterComponent } from './register/register.component';
import { ProductService } from './services/product.service';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { PaymentComponent } from './payment/payment.component';
import { FruitsComponent } from './fruits/fruits.component';
import { ReadyToEatComponent } from './readytoeat/readytoeat.component';
import { LogoutComponent } from './logout/logout.component';
import { FooterComponent } from './footer/footer.component';
import {  VegetablesComponent } from './vegetables/vegetables.component';
//import { OrderComponent } from './order/order.component';
import { OrderConfirmationComponent } from './order-confirmation/order-confirmation.component';

//import { SerachComponent } from './serach/serach.component';



//import { SnacksComponent } from './snacks/snacks.component';



@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    LoginComponent,
    NavbarComponent,
    ProfileComponent,
    RegisterComponent,
    HomeComponent,
    CartComponent,
    WishlistComponent,
    PaymentComponent,
    FruitsComponent,
    ReadyToEatComponent,
    LogoutComponent,
    FooterComponent,
    VegetablesComponent,
    //OrderComponent,
    OrderConfirmationComponent,
    
    
    
    //SnacksComponent
 
   // Declare your components here
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, // Add FormsModule here
    ReactiveFormsModule, 
    HttpClientModule,// Add ReactiveFormsModule here (if required)
    RouterModule.forRoot([
      { path: 'signup', component: SignupComponent },
      { path: 'login', component: LoginComponent },
      {path:'register', component:RegisterComponent},
      {path : 'home', component:HomeComponent},
      {path : 'wishlist', component:WishlistComponent},
      {path:'cart', component:CartComponent},
      { path: 'profile', component: ProfileComponent },
      {path:'payment',component:PaymentComponent},
      { path: 'fruits', component: FruitsComponent },
      {path:'readyToEat', component: ReadyToEatComponent},
      { path: 'logout', component: LogoutComponent },
      { path:'vegetables', component:VegetablesComponent},
      { path: 'order-confirmation', component: OrderConfirmationComponent },
      //path:'snacks',component:SnacksComponent}
    ]), // Add routes
  ],
  providers: [ProductService,provideHttpClient(withFetch()),],
  bootstrap: [AppComponent],
})
export class AppModule {}
