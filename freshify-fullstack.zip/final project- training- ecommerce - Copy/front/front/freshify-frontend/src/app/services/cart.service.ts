
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';  // Import HttpClient
interface CartItem {
  name: string;
  quantity: number;
  price: number;
  image: string;
}
 
@Injectable({
  providedIn: 'root',
})
 
 
export class CartService {
  private cartCount = new BehaviorSubject<number>(0); // Cart item count observable
  cartCount$ = this.cartCount.asObservable(); // Observable to track cart item count
 
  private apiUrl = 'http://localhost:5000/api/cart'; // Define your API base URL here
 
 
  constructor(private http: HttpClient) {}
 
  // Fetch updated cart from backend and notify observers
private fetchAndNotifyCart() {
  this.getCart().subscribe((cart: any) => {
    console.log('Updated cart from backend:', cart);
    const totalCount = cart.items.reduce((acc: number, item: CartItem) => acc + item.quantity, 0);
    this.cartCount.next(totalCount);
  });
}
 
 
 
  // Fetch cart items from the backend
  getCart() {
    return this.http.get<any>(this.apiUrl);
  }
 
  // Add item to cart (via backend)
  addToCart(product: any, quantity: number = 1) {
    return this.http.post(`${this.apiUrl}/add`, {
      name: product.name,
      quantity,
      price: product.price,
      image: product.image,
    }).subscribe(() => this.updateCartState());
  }
 
  // Remove item from cart (via backend)
  removeFromCart(productName: string) {
    // return this.http.delete(`${this.apiUrl}/remove`, { body: { name: productName } })
    //   .subscribe(() => this.updateCartState());
    return this.http.delete(`${this.apiUrl}/remove`, { body: { name: productName } }).subscribe(() => {
      this.fetchAndNotifyCart(); // Sync cart after removal
    });
  }
 
  // Clear the cart (via backend)
  clearCart() {
    // return this.http.delete(`${this.apiUrl}/clear`).subscribe(() => this.updateCartState());
    return this.http.delete(`${this.apiUrl}/clear`).subscribe(() => {
      this.fetchAndNotifyCart(); // Sync cart after clearing
    });
  }
 
  // Update cart item count
  private updateCartState() {
    this.getCart().subscribe(cart => {
      const totalCount = cart.items.reduce((acc:number, item:CartItem) => acc + item.quantity, 0);
      this.cartCount.next(totalCount);
    });
  }
}