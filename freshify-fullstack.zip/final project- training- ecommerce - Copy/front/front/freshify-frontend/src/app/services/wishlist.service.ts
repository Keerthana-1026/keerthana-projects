import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class WishlistService {
  private apiUrl = 'http://localhost:5000/api/wishlist'; // API endpoint

  constructor(private http: HttpClient) {}

  // Fetch all wishlist items
  getWishlist(): Observable<any> {
    return this.http.get<any>(this.apiUrl);
  }

  // Add an item to the wishlist
  addToWishlist(item: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, item);
  }

  // Remove an item from the wishlist
  removeFromWishlist(itemId: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${itemId}`);
  }

  // Clear the entire wishlist
  clearWishlist(): Observable<any> {
    return this.http.delete<any>(this.apiUrl);
  }
}
