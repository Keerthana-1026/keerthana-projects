import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseUrl = 'http://localhost:5000/api/users'; // Backend URL

  constructor(private http: HttpClient) {}

  // Signup API Call
  signup(userData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/signup`, userData);
  }

  // Login API Call
  login(credentials: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, credentials);
  }


  // Logout method to clear the user session
  logout(): void {
    // Remove user session data from localStorage or sessionStorage
    localStorage.removeItem('auth_token'); // Example: Removing JWT token
    // If you are storing user information (like user data), remove it as well
    localStorage.removeItem('user_data');
  }

  // Optionally, you can add a method to check if the user is logged in
  isLoggedIn(): boolean {
    // Return true if the auth token exists, indicating the user is logged in
    return !!localStorage.getItem('auth_token');
  }
}
