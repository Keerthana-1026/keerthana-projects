import { Component, OnInit } from '@angular/core';
import { WishlistService } from '../services/wishlist.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css'],
})
export class WishlistComponent implements OnInit {
  wishlistItems: any[] = []; // Array to store wishlist items

  constructor(private wishlistService: WishlistService) {}

  ngOnInit(): void {
    this.loadWishlist();
  }

  // Load all wishlist items
  loadWishlist(): void {
    this.wishlistService.getWishlist().subscribe(
      (data) => {
        this.wishlistItems = data;
      },
      (error) => {
        console.error('Error fetching wishlist items', error);
      }
    );
  }

  // Remove an item from the wishlist
  removeFromWishlist(itemId: string): void {
    this.wishlistService.removeFromWishlist(itemId).subscribe(
      () => {
        this.wishlistItems = this.wishlistItems.filter((item) => item._id !== itemId);
        alert('Item removed from wishlist');
      },
      (error) => {
        console.error('Error removing item from wishlist', error);
      }
    );
  }
  addItemToWishlist() {
    const newItem = {
      name: 'Item Name',
      description: 'Item Description',
      price: 100,
      image: '/uploads/image-name.jpg' // Full path to the image
    };
  
    this.wishlistService.addToWishlist(newItem).subscribe(
      (response) => {
        alert('Item added to wishlist');
        this.loadWishlist(); // Refresh the wishlist
      },
      (error) => {
        console.error('Error adding item to wishlist', error);
      }
    );
  }  

  // Clear all wishlist items
  clearWishlist(): void {
    this.wishlistService.clearWishlist().subscribe(
      () => {
        this.wishlistItems = [];
        alert('Wishlist cleared successfully');
      },
      (error) => {
        console.error('Error clearing wishlist', error);
      }
    );
  }
}
