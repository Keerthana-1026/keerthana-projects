import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-profile',
  template: `
    <h2>User Profile</h2>
    <div *ngIf="profile">
      <p><strong>Full Name:</strong> {{ profile.fullName }}</p>
      <p><strong>Username:</strong> {{ profile.username }}</p>
      <p><strong>Email:</strong> {{ profile.email }}</p>
      <button (click)="editProfile()">Edit Profile</button>
    </div>
  `
})
export class ProfileComponent implements OnInit {
  profile: any;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    const token = localStorage.getItem('token');
    this.http.get('http://localhost:5000/api/users/profile', {
      headers: { Authorization: token || '' }
    }).subscribe(
      (data) => this.profile = data,
      (error) => alert('Error fetching profile')
    );
  }

  editProfile() {
    // Implement editing functionality here
  }
}
