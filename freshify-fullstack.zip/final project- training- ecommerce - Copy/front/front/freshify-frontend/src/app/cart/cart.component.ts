// // cart.service.ts
// import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';
// import { HttpClient } from '@angular/common/http';  // Import HttpClient
// interface CartItem {
//   name: string;
//   quantity: number;
//   price: number;
//   image: string;
// }
 
// @Injectable({
//   providedIn: 'root',
// })
 
 
// export class CartService {
//   private cartCount = new BehaviorSubject<number>(0); // Cart item count observable
//   cartCount$ = this.cartCount.asObservable(); // Observable to track cart item count
 
//   private apiUrl = 'http://localhost:5000/api/cart'; // Define your API base URL here
 
 
//   constructor(private http: HttpClient) {}
 
//   // Fetch updated cart from backend and notify observers
// private fetchAndNotifyCart() {
//   this.getCart().subscribe((cart: any) => {
//     console.log('Updated cart from backend:', cart);
//     const totalCount = cart.items.reduce((acc: number, item: CartItem) => acc + item.quantity, 0);
//     this.cartCount.next(totalCount);
//   });
// }
 
 
 
//   // Fetch cart items from the backend
//   getCart() {
//     return this.http.get<any>(this.apiUrl);
//   }
 
//   // Add item to cart (via backend)
//   addToCart(product: any, quantity: number = 1) {
//     return this.http.post(`${this.apiUrl}/add`, {
//       name: product.name,
//       quantity,
//       price: product.price,
//       image: product.image,
//     }).subscribe(() => this.updateCartState());
//   }
 
//   // Remove item from cart (via backend)
//   removeFromCart(productName: string) {
//     // return this.http.delete(`${this.apiUrl}/remove`, { body: { name: productName } })
//     //   .subscribe(() => this.updateCartState());
//     return this.http.delete(`${this.apiUrl}/remove`, { body: { name: productName } }).subscribe(() => {
//       this.fetchAndNotifyCart(); // Sync cart after removal
//     });
//   }
 
//   // Clear the cart (via backend)
//   clearCart() {
//     // return this.http.delete(`${this.apiUrl}/clear`).subscribe(() => this.updateCartState());
//     return this.http.delete(`${this.apiUrl}/clear`).subscribe(() => {
//       this.fetchAndNotifyCart(); // Sync cart after clearing
//     });
//   }
 
//   // Update cart item count
//   private updateCartState() {
//     this.getCart().subscribe(cart => {
//       const totalCount = cart.items.reduce((acc:number, item:CartItem) => acc + item.quantity, 0);
//       this.cartCount.next(totalCount);
//     });
//   }
//}
import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
 
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: any[] = [];
  totalAmount: number = 0;
 
  constructor(private cartService: CartService) {}
 
  ngOnInit(): void {
    // // Subscribe to cart changes and update the cart items
    // this.cartService.cartCount$.subscribe(() => {
    //   this.cartItems = this.cartService.getCart(); // Get cart items from CartService
    //   this.calculateTotalAmount(); // Recalculate the total amount
    // });
    // Subscribe to cart service to get cart items
    this.cartService.getCart().subscribe((cart: any) => {
      this.cartItems = cart.items;  // Assuming cart.items is an array
      this.calculateTotalAmount();
      this.refreshCart(); // Reload cart after removal   add on i did try remove if o/p doesnt work
    });
  }
 
  // Refresh cart data
private refreshCart(): void {
  this.cartService.getCart().subscribe((cart: any) => {
    console.log('Refreshed cart in UI:', cart);
    this.cartItems = cart.items || [];
    this.calculateTotalAmount();
  });
}
 
 
  // Remove item from cart
  removeFromCart(productName: string): void {
    this.cartService.removeFromCart(productName); // Call CartService to remove item //removeFromCart
    setTimeout(() => {
      this.refreshCart(); // Wait for the backend to update and then refresh cart
    }, 100);
    this.calculateTotalAmount(); // Recalculate total after removal
  }
 
  // Clear all items from the cart
  clearCart(): void {
    this.cartService.clearCart(); // Call CartService to clear cart
    this.calculateTotalAmount(); // Recalculate total after clearing
    setTimeout(() => {
      this.refreshCart(); // Wait for the backend to update and then refresh cart
    }, 100);  //  add on i did try remove if o/p doesnt work
  }
 
  // Update quantity of a specific item
  updateQuantity(item: any, change: number): void {
    if (item.quantity + change >= 1) {
      item.quantity += change; // Update the item quantity
      this.cartService.addToCart(item, 0); // Update cart state using CartService
      this.calculateTotalAmount(); // Recalculate total after quantity update
    }
  }
  // Calculate the total amount
  calculateTotalAmount(): void {
    this.totalAmount = this.cartItems.reduce((total, item) => {
      return total + (item.price * item.quantity);
    }, 0);
  }
} 