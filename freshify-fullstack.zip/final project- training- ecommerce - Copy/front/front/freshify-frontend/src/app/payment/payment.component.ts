import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent {
  selectedPaymentMethod: string = '';
  cardNumber: string = '';
  cvv: string = '';
  phoneNumber: string = '';
  deliveryInstructions: string = '';
  address: string = '';
  landmark: string = '';
  deliveryDate: string = '';
  leaveAtDoor: boolean = false;
  ringBell: boolean = false;
  callOnArrival: boolean = false;
  pin:string='';

  constructor(private router: Router) {}

  completePayment(): void {
    if (this.selectedPaymentMethod === 'card') {
      if (!/^\d{16}$/.test(this.cardNumber) || !/^\d{3}$/.test(this.cvv)) {
        alert('Invalid card details!');
        return;
      }
    } else if (this.selectedPaymentMethod === 'upi') {
      if (!/^\d{10}$/.test(this.phoneNumber)) {
        alert('Invalid phone number!');
        return;
      }
    }

    // Navigate to the order confirmation page after successful payment
    this.router.navigate(['/order-confirmation']);
  }
}
