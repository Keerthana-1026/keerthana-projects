import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';  // Your authentication service

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  message: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    // Call logout method from AuthService to clear user session or token
    this.authService.logout();
    this.message = 'Logged out successfully! Please login to continue.';
    
    // Optionally, you can redirect after a certain time
    setTimeout(() => {
      this.router.navigate(['/login']);
    }, 3000); // Redirect to login page after 3 seconds
  }
}
