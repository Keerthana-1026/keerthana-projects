import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service'; // Import AuthService
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent {
  userData = {
    fullName: '',
    username: '',
    password: '',
    email: '',
    phone: ''
  };

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    this.authService.signup(this.userData).subscribe(
      (response) => {
        console.log('Signup successful:', response);
        alert('Signup successful!');
        this.router.navigate(['/login']); // Redirect to login page
      },
      (error) => {
        console.error('Signup error:', error);
        if (error.status === 400 && error.error.msg === 'User already exists') {
          alert('Username is already taken. Please choose another one.');
        } else {
          alert('An unexpected error occurred. Please try again.');
        }
      }
    );
  }
}
